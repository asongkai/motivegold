'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"flutter_bootstrap.js": "411dea9e511dddc37e69db4632ba5678",
"version.json": "065668dc60a752de7047b05a0feec51e",
"index.html": "c98fb23df8415039bd7933359d480df7",
"/": "c98fb23df8415039bd7933359d480df7",
"main.dart.js": "82ee239bbc8cc98f84ab81e4c035198b",
"flutter.js": "888483df48293866f9f41d3d9274a779",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"manifest.json": "e849cea40522777878fca5895378b8d0",
"assets/AssetManifest.json": "2892fbab85e14f62deab5468d7bbe668",
"assets/NOTICES": "dc7d2315ebcdb6c72d20207f30d289c4",
"assets/FontManifest.json": "7a19d3e527637269a566a47bfa030773",
"assets/AssetManifest.bin.json": "4a7f8c52db491ac6144fe8e49a25ef3b",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "9517e4f3873e1adfa0cc73532a3ff19d",
"assets/packages/font_awesome_flutter/lib/fonts/fa-solid-900.ttf": "2584fa7285348fa05fc33f03941f7cd1",
"assets/packages/font_awesome_flutter/lib/fonts/fa-regular-400.ttf": "3ca5dc7621921b901d513cc1ce23788c",
"assets/packages/font_awesome_flutter/lib/fonts/fa-brands-400.ttf": "4769f3245a24c1fa9965f113ea85ec2a",
"assets/packages/syncfusion_flutter_datepicker/assets/fonts/Roboto-Medium.ttf": "7d752fb726f5ece291e2e522fcecf86d",
"assets/packages/empty_widget_fork/assets/images/im_emptyIcon_1.png": "545e13e1cabb2faf7eac9801f64f7f89",
"assets/packages/empty_widget_fork/assets/images/im_emptyIcon_3.png": "2698f6c94cec9450ced97499b70a34d6",
"assets/packages/empty_widget_fork/assets/images/im_emptyIcon_2.png": "bcff5e23332d92e74562eaf8f47c7bd1",
"assets/packages/empty_widget_fork/assets/images/emptyImage.png": "6bb2d2c61bb39c0c571b95ae009acc4b",
"assets/packages/awesome_dialog/assets/rive/info_reverse.riv": "c6e814d66c0e469f1574a2f171a13a76",
"assets/packages/awesome_dialog/assets/rive/question.riv": "00f02da4d08c2960079d4cd8211c930c",
"assets/packages/awesome_dialog/assets/rive/warning.riv": "0becf971559a68f9a74c8f0c6e0f8335",
"assets/packages/awesome_dialog/assets/rive/info.riv": "2a425920b11404228f613bc51b30b2fb",
"assets/packages/awesome_dialog/assets/rive/success.riv": "73618ab4166b406e130c2042dc595f42",
"assets/packages/awesome_dialog/assets/rive/error.riv": "e74e21f8b53de4b541dd037c667027c1",
"assets/packages/awesome_dialog/assets/flare/succes.flr": "ebae20460b624d738bb48269fb492edf",
"assets/packages/awesome_dialog/assets/flare/succes_without_loop.flr": "3d8b3b3552370677bf3fb55d0d56a152",
"assets/packages/awesome_dialog/assets/flare/error.flr": "e3b124665e57682dab45f4ee8a16b3c9",
"assets/packages/awesome_dialog/assets/flare/info2.flr": "21af33cb65751b76639d98e106835cfb",
"assets/packages/awesome_dialog/assets/flare/warning_without_loop.flr": "c84f528c7e7afe91a929898988012291",
"assets/packages/awesome_dialog/assets/flare/info_without_loop.flr": "cf106e19d7dee9846bbc1ac29296a43f",
"assets/packages/awesome_dialog/assets/flare/warning.flr": "68898234dacef62093ae95ff4772509b",
"assets/packages/awesome_dialog/assets/flare/info.flr": "bc654ba9a96055d7309f0922746fe7a7",
"assets/packages/awesome_dialog/assets/flare/question.flr": "1c31ec57688a19de5899338f898290f0",
"assets/packages/getwidget/icons/slack.png": "19155b848beeb39c1ffcf743608e2fde",
"assets/packages/getwidget/icons/twitter.png": "caee56343a870ebd76a090642d838139",
"assets/packages/getwidget/icons/linkedin.png": "822742104a63a720313f6a14d3134f61",
"assets/packages/getwidget/icons/dribble.png": "1e36936e4411f32b0e28fd8335495647",
"assets/packages/getwidget/icons/youtube.png": "1bfda73ab724ad40eb8601f1e7dbc1b9",
"assets/packages/getwidget/icons/line.png": "da8d1b531d8189396d68dfcd8cb37a79",
"assets/packages/getwidget/icons/pinterest.png": "d52ccb1e2a8277e4c37b27b234c9f931",
"assets/packages/getwidget/icons/whatsapp.png": "30632e569686a4b84cc68169fb9ce2e1",
"assets/packages/getwidget/icons/google.png": "596c5544c21e9d6cb02b0768f60f589a",
"assets/packages/getwidget/icons/wechat.png": "ba10e8b2421bde565e50dfabc202feb7",
"assets/packages/getwidget/icons/facebook.png": "293dc099a89c74ae34a028b1ecd2c1f0",
"assets/packages/progress_dialog_null_safe/assets/double_ring_loading_io.gif": "a03b96c4f7bef9fd9ed90eb516267a11",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/AssetManifest.bin": "759aa9b612c6b1079eb22f17885ec1a2",
"assets/fonts/MaterialIcons-Regular.otf": "b8ab90c664baa94778006381a710ccdc",
"assets/assets/no_internet_connection.json": "a2c649bd703d2259d04bd95b2e8d0ede",
"assets/assets/locale/lo-LA.json": "1c23a6e49f14940ffc6078b874b0eb85",
"assets/assets/locale/zh-CN.json": "1e8af00547df2e82f3452218509383a8",
"assets/assets/locale/en-US.json": "0555f3ab6e2d201a143d15243adec458",
"assets/assets/locale/vi-VN.json": "a6dddf4b4c5cabf2feda5d1ef2165cf7",
"assets/assets/flags/my_flag.png": "c4d01190f4cfc542c7901cfbae03bb32",
"assets/assets/flags/ru_flag.png": "3555c09699cfbad8a853e78365fa0be1",
"assets/assets/flags/mx_flag.png": "7b07e78c690eb5aa69cca1e34ec2641e",
"assets/assets/flags/ph_flag.png": "c8080910a9a03529548f6d522b5748ba",
"assets/assets/flags/dz_flag.png": "8ab9a658aab75af6e8e911730180f8d8",
"assets/assets/flags/km_flag.png": "4dbf3baf6840e9b5acbc0ab1e0d3e260",
"assets/assets/flags/iq_flag.png": "8c3acdc72581c4639f0102da2ab46fef",
"assets/assets/flags/bo_flag.png": "0312bc40dd42af4b61de9c61dd516941",
"assets/assets/flags/bn_flag.png": "fb56f0e97cd138562e3470ec1c3fb90c",
"assets/assets/flags/sg_flag.png": "9eca0fcdec284f968c648df587b8fda1",
"assets/assets/flags/lk_flag.png": "830b8599331faedc0b09cdab20d0a5d5",
"assets/assets/flags/gu_flag.png": "2efb91c28ef94092b3ff38cdb5a0b9ac",
"assets/assets/flags/gt_flag.png": "621dda6da8c7a19af64580c631bd959b",
"assets/assets/flags/eh_flag.png": "1c33c9a0c24d798c1c13b090742e3676",
"assets/assets/flags/us_flag.png": "abdb9eaeaea92f08fcf0169388a44094",
"assets/assets/flags/be_flag.png": "d74e47abf06adf4810ab6f4fdb3e4393",
"assets/assets/flags/bd_flag.png": "61e33ab9a343f382ea384fcb5cc22b57",
"assets/assets/flags/tj_flag.png": "2a7eb3501304102dced5c7624638ca21",
"assets/assets/flags/kg_flag.png": "314f949fe02a346c75f6c7bd1d287324",
"assets/assets/flags/tk_flag.png": "e1f4f54e23f1e50ba843d0e672bea3af",
"assets/assets/flags/fm_flag.png": "091443e6c3ae5f13895329ecd07aed01",
"assets/assets/flags/ms_flag.png": "3ab71eb637ed6b44bf3fa69df53d2fcd",
"assets/assets/flags/mr_flag.png": "aa79f42276a7e14804a3242d6733f17b",
"assets/assets/flags/cv_flag.png": "a695bff9ee80fd5b37c64c0d3e770333",
"assets/assets/flags/cw_flag.png": "8cd49a4f9db22ab9344f5ab0663403ce",
"assets/assets/flags/uy_flag.png": "6897737de3b04e00aec559ac71d2305b",
"assets/assets/flags/ec_flag.png": "ba64150dfe034b0f387d329b812716d8",
"assets/assets/flags/sm_flag.png": "6c9ea47780d4b53b3ba1d56f7f801299",
"assets/assets/flags/sl_flag.png": "5d2ec044deee7c127a70f22ca7ad5ebf",
"assets/assets/flags/la_flag.png": "1e8427cf81bc09bf211be1645171f980",
"assets/assets/flags/au_flag.png": "d45f85bdb80db9e6ed7643f5c8c6ec5c",
"assets/assets/flags/at_flag.png": "a18bad7322e8b51fd5c5129a7042516c",
"assets/assets/flags/ch_flag.png": "b8cfb34778d684f066ec41ff87660b07",
"assets/assets/flags/ci_flag.png": "7d7b436c8bbc28447d22acb61683dacc",
"assets/assets/flags/ug_flag.png": "7db072e124f7b9102c12437d6228f568",
"assets/assets/flags/ga_flag.png": "437e7e84263da9f80d91a086c714ec12",
"assets/assets/flags/ss_flag.png": "f9dd8fb5c94a0955a313e7b4a203bac9",
"assets/assets/flags/sr_flag.png": "f942cf25a1f1239ddb6269df8f10344e",
"assets/assets/flags/nc_flag.png": "31b829b49e68977d2b0a36a28f09b6d9",
"assets/assets/flags/bz_flag.png": "a0b9a5d8b33e85ec70acf4b829e4c847",
"assets/assets/flags/tt_flag.png": "584b07cc9a6bf0321615257c1f57edcf",
"assets/assets/flags/ky_flag.png": "f9726e89bff7974e5d3947d8d1c40d72",
"assets/assets/flags/id_flag.png": "299819c701f836496ed47c75122c56f0",
"assets/assets/flags/vi_flag.png": "472d5bb965de8d32e964f299b10d9b35",
"assets/assets/flags/ie_flag.png": "0a76cb28630dfbb30e1c6584fd994368",
"assets/assets/flags/fr_flag.png": "21a8fcef26541cc6799d23925a0fbb61",
"assets/assets/flags/do_flag.png": "8ff92d7bd2e34c0b1e8e8dd6624d9f65",
"assets/assets/flags/mm_flag.png": "efdbe0f591b74a21774ba385266d20aa",
"assets/assets/flags/ml_flag.png": "62dccd0e06a95677e2a0455aa344c4b6",
"assets/assets/flags/ni_flag.png": "37a3bb06030ff2c2006b1e1bbf11f285",
"assets/assets/flags/lt_flag.png": "fca587b9981a3bc1525ac4f8c5d62d6f",
"assets/assets/flags/sy_flag.png": "112ab41ba56ca4c6b52571257bcbde07",
"assets/assets/flags/lu_flag.png": "7a22982c50b5ae0bb4eb5057e9c3d2f1",
"assets/assets/flags/sx_flag.png": "eb38e97253478048a24252f517470aec",
"assets/assets/flags/um_flag.png": "abdb9eaeaea92f08fcf0169388a44094",
"assets/assets/flags/cc_flag.png": "526424847969574b5d9dc31a2556bb3d",
"assets/assets/flags/pw_flag.png": "8515f83eea1c21fb807f1707c27c8d37",
"assets/assets/flags/mg_flag.png": "5be9c0ce8ba49e4290517ec5b9602842",
"assets/assets/flags/mf_flag.png": "61a4b56839ae1a9b9ea116d11aad5cc8",
"assets/assets/flags/de_flag.png": "6a0d933a60d0615e3072ba39b4033f42",
"assets/assets/flags/yt_flag.png": "276613d5700bdba546c682474ba604d3",
"assets/assets/flags/vc_flag.png": "38abd033f9fd10a83cf666228898ec13",
"assets/assets/flags/in_flag.png": "a089735fafa19236e5792cf9118ee119",
"assets/assets/flags/io_flag.png": "04658a684f4faa9d730b56611404cbc2",
"assets/assets/flags/kr_flag.png": "422739e4e8cdd8884bb53de32980b1e1",
"assets/assets/flags/bq_flag.png": "1db1bf6b2c46b3db56e62e018b03e0c4",
"assets/assets/flags/jm_flag.png": "1b0f67a5b93838145d5ce9a14c99c1c4",
"assets/assets/flags/ua_flag.png": "fb465ab21b5b6bab19f8b2bc4846984c",
"assets/assets/flags/ar_flag.png": "a539bb824a67b735ca56e5cd7561564d",
"assets/assets/flags/as_flag.png": "a9fd1fd7c7aba6bcaf474a3e4fa40680",
"assets/assets/flags/co_flag.png": "af2459b5393b1f22a2263b3f96667b70",
"assets/assets/flags/cn_flag.png": "20f4dfb10bb0053e60445cfd7f629851",
"assets/assets/flags/st_flag.png": "d9193ea8f52504ee98dce95a8145dae0",
"assets/assets/flags/ly_flag.png": "ad626d38754878189df14a992baaf567",
"assets/assets/flags/ne_flag.png": "7b9346fb189002457cf05365ff2f9458",
"assets/assets/flags/gf_flag.png": "766770324f2d28d71cc4a1d6c3c3ab87",
"assets/assets/flags/xk_flag.png": "3b5a8b36320c9da7a59500ff09ba730a",
"assets/assets/flags/gg_flag.png": "72bad4a9c1145db2035a73cafae2ffc6",
"assets/assets/flags/zw_flag.png": "1e7c4f330998eca3a92bbd35e86b5ffa",
"assets/assets/flags/tr_flag.png": "4e6d6439a361c61bf0e6a31aae70ee1e",
"assets/assets/flags/vn_flag.png": "17a5f32877ab1b41b516d7f2f73d4a19",
"assets/assets/flags/mk_flag.png": "eb1041b01ad59d4d5af0610425569f3f",
"assets/assets/flags/gl_flag.png": "5ba9d07cd8aa050e6a32ea17ba080af7",
"assets/assets/flags/gm_flag.png": "8687120ec195ada93b57968bc469bbab",
"assets/assets/flags/no_flag.png": "6c3a6394b52f988dcda22eec448c52a4",
"assets/assets/flags/ls_flag.png": "ed6d74f205e1d4a491ac77e108943b49",
"assets/assets/flags/lr_flag.png": "6ff6d059f4396c1c6faf430ba34b27c9",
"assets/assets/flags/cd_flag.png": "65d7fdb32fb4429ca8e4a510cb5bfd8d",
"assets/assets/flags/ax_flag.png": "07b3b214a9cd02604b297c77de21e4ce",
"assets/assets/flags/ma_flag.png": "a8e651c4a44bb9e7f9b660038908a36e",
"assets/assets/flags/bv_flag.png": "b8b7d27a67317aaed9399475838294b8",
"assets/assets/flags/bw_flag.png": "64beb3a9bcc712fd2f47c1219c81ff9e",
"assets/assets/flags/ve_flag.png": "f25867cf6a9670485e7ddaf9a31ab63d",
"assets/assets/flags/rs_flag.png": "ec0601641bd449df16a9c2388ad30ebb",
"assets/assets/flags/pn_flag.png": "bcbf056ce0dcf783e89dfba03c68d314",
"assets/assets/flags/bh_flag.png": "f1a57144288f5e04967af5b738023f4c",
"assets/assets/flags/bi_flag.png": "867c0a6618cf54dd5b14efd2284019b4",
"assets/assets/flags/tg_flag.png": "d1152a67f4ce2e63c3c12e58f45758ee",
"assets/assets/flags/tf_flag.png": "47ffe92c77d9ce3dde8189207709a1b9",
"assets/assets/flags/gr_flag.png": "b8dea2afe9be5ba28c3e19614f8ae60d",
"assets/assets/flags/gs_flag.png": "d3cdf922146fecc76215e5a6c8632d94",
"assets/assets/flags/sa_flag.png": "c4735a2685b8ab92e7b0a6d0e8c38a39",
"assets/assets/flags/np_flag.png": "f6628d56921151630320b3d2dfab23ed",
"assets/assets/flags/af_flag.png": "819130bbfa740fcc941d041d7c7fd96a",
"assets/assets/flags/ag_flag.png": "64ccccfd560e30cd3d43f741869c5b61",
"assets/assets/flags/cz_flag.png": "d2e8b4d34c744c6bda260949e77ce296",
"assets/assets/flags/tm_flag.png": "4052cd152ed94bd578ff7a77799dcfff",
"assets/assets/flags/tl_flag.png": "4019df92cf74cdb8c8b5add0eba8a3d0",
"assets/assets/flags/bb_flag.png": "b98f25fd38c9e23241ddd785c14a5a7d",
"assets/assets/flags/pe_flag.png": "77749b89d70e961eeaa48282d599ab11",
"assets/assets/flags/mt_flag.png": "e5084ab5c9ff59c540495e3b4c380785",
"assets/assets/flags/mu_flag.png": "ac3bcf7eabdfb538d6bd534ddba0791d",
"assets/assets/flags/fk_flag.png": "c4dd2a3c3337072f7ae69d8d00a51ac8",
"assets/assets/flags/fj_flag.png": "1dda8525345ecc632840d6ddc3168293",
"assets/assets/flags/hn_flag.png": "458b40af6876eb96d345f84be65c5f77",
"assets/assets/flags/al_flag.png": "c240f7bc18a614cdfadae5767745f892",
"assets/assets/flags/am_flag.png": "708c04e0980c0b1a10f609f69630e776",
"assets/assets/flags/nz_flag.png": "a50e059b008815613eb863368b5504ec",
"assets/assets/flags/sj_flag.png": "fef140278f400504592888f440ebcac8",
"assets/assets/flags/sk_flag.png": "d8435059f09134d6bbfcb71c6d539e60",
"assets/assets/flags/ee_flag.png": "6de03e75b9da7d5f04da4202199d9b56",
"assets/assets/flags/gy_flag.png": "0baf3a119b26ae2646b956dba27f8a22",
"assets/assets/flags/sz_flag.png": "19a56857c5544ebdfc6c8eccf0243e70",
"assets/assets/flags/lv_flag.png": "5096d143c7227c46e8ff8ed660b0ede4",
"assets/assets/flags/gh_flag.png": "63ab62571e49fffe666ed53169db8f65",
"assets/assets/flags/gi_flag.png": "006a280784c791837904f7b807cdb9f4",
"assets/assets/flags/et_flag.png": "585b4078e02d9ab06e840b3229636c14",
"assets/assets/flags/ws_flag.png": "b13508ec46a065102cf6c0bdb06cf782",
"assets/assets/flags/ca_flag.png": "10543cf2d176c0bfdfd54c497164422e",
"assets/assets/flags/md_flag.png": "0e828aca3c4f7cddf55f601ebeb6da90",
"assets/assets/flags/me_flag.png": "dae3fae9943c8df523baa8c5ca6d002d",
"assets/assets/flags/pt_flag.png": "269f3710ef3a74d52ff5b628020bb77f",
"assets/assets/flags/kp_flag.png": "37081ae8cff32e3c433fa2913145ec41",
"assets/assets/flags/im_flag.png": "57afc39373405b5f480f7c2431aeb22a",
"assets/assets/flags/il_flag.png": "5a4223251b798a1efd33a3810f0934aa",
"assets/assets/flags/va_flag.png": "eee8b4609a4e198c77b550249cbc75e4",
"assets/assets/flags/br_flag.png": "d316c8ccb9f5c7f76d653a71f6204dda",
"assets/assets/flags/bs_flag.png": "d2640000e2db2aa8f800a1c9b64b084f",
"assets/assets/flags/ck_flag.png": "6ba6b9775af9c2cf4ca99aa2d1ed8d75",
"assets/assets/flags/aw_flag.png": "ed8264d2c7c817d1068ae0a12a8481e2",
"assets/assets/flags/ht_flag.png": "daca600163003aab25402f23ba31a76c",
"assets/assets/flags/hu_flag.png": "11718241f9c140ad9fb9f67961b881de",
"assets/assets/flags/gb_flag.png": "21ddaaa5d5420e071455d35db1388345",
"assets/assets/flags/na_flag.png": "3ba276570ab0e9569d4b38eddb19a672",
"assets/assets/flags/by_flag.png": "20d55df984b334c6e1e3d2db71c37bb6",
"assets/assets/flags/kz_flag.png": "9e40c39ffa000c56ad72f7efd6c51967",
"assets/assets/flags/tw_flag.png": "9cc37a8fb944f515bd6c58c796359aeb",
"assets/assets/flags/tv_flag.png": "ebef4383bd5cd212383807c13ca4b8c1",
"assets/assets/flags/dm_flag.png": "273bc446050f1afa9d2269426f2d2a43",
"assets/assets/flags/mn_flag.png": "df74aaa3daf91a62703f85b7b2de6ea3",
"assets/assets/flags/mo_flag.png": "05df3459a6136922ff6049e099091739",
"assets/assets/flags/bf_flag.png": "8f97bb6b156f224e7bb925b77c44f02e",
"assets/assets/flags/bg_flag.png": "aab83a15306b99ece758731073a644f1",
"assets/assets/flags/ke_flag.png": "daf679070bb1b525e123aee91c993b1f",
"assets/assets/flags/th_flag.png": "64ebab779a716b4c6690731779b0be43",
"assets/assets/flags/vu_flag.png": "902329729a5e7f606725bfcfbfa66763",
"assets/assets/flags/fo_flag.png": "9dc5e581432ec3d57655ddac9982a0d4",
"assets/assets/flags/mp_flag.png": "8aca9626781bd80374774cbcddb69daa",
"assets/assets/flags/mq_flag.png": "4506d0b38da5574f447a957412d93c5f",
"assets/assets/flags/om_flag.png": "645c29d58d11753c87d8e26c6616a501",
"assets/assets/flags/pa_flag.png": "01c8f9463555972b5444abda02b9f7fa",
"assets/assets/flags/ai_flag.png": "ef37523ebdde0a9d59238ca46ce0c3e8",
"assets/assets/flags/cu_flag.png": "0c7d92c0099b4f834c559dfa480d68dc",
"assets/assets/flags/ic_launcher.png": "f6628d56921151630320b3d2dfab23ed",
"assets/assets/flags/uz_flag.png": "89f8a51b82e0ef20a22ba2aafb02e9ea",
"assets/assets/flags/hk_flag.png": "22f206ddd84168f0fde5016907672135",
"assets/assets/flags/wf_flag.png": "af154a7dd02fff460c23f8e09304946d",
"assets/assets/flags/zm_flag.png": "f38794aecd08dac5594f2c71af739f99",
"assets/assets/flags/lc_flag.png": "d5805f73b7e41bb1fff3d6910557d4d9",
"assets/assets/flags/sn_flag.png": "079c26f7d050647969b1379da84d7082",
"assets/assets/flags/lb_flag.png": "1cf9c62e89bd78e82543acbd5c424dc9",
"assets/assets/flags/so_flag.png": "9f2e5dbc0636a158101cab4e6d79c29a",
"assets/assets/flags/pk_flag.png": "0f30bb963d68d347b426df92084acf5c",
"assets/assets/flags/mz_flag.png": "e796da8ba66c0afb4cedbd670123b7d2",
"assets/assets/flags/rw_flag.png": "c6d58417624782a6dda7f64c70e9f896",
"assets/assets/flags/is_flag.png": "a4f5ce05c17d6ee14db4d3b37ebd7f6f",
"assets/assets/flags/ir_flag.png": "64a3f3f7d2c7ead1d16afdd8c3a839f3",
"assets/assets/flags/tc_flag.png": "2dd33013e2b81cca14366a04ed23ec1b",
"assets/assets/flags/kn_flag.png": "588ce130b0fd1afc53df311ac113f730",
"assets/assets/flags/bl_flag.png": "f422c2d9d53d4abf1f927d147e393ac2",
"assets/assets/flags/bm_flag.png": "3ba7dcc12455bf3cf6c84a4b51e1a7dd",
"assets/assets/flags/nu_flag.png": "1d4a9c7be55766c2fd20b692f86cc8ac",
"assets/assets/flags/sd_flag.png": "afa8abde25f16bdcfbd86336efe50969",
"assets/assets/flags/li_flag.png": "68ae07fdd8f7e8c27dc6cf1dc6593239",
"assets/assets/flags/se_flag.png": "d6362cb84019ccfbb7d3fff4a93e8ec1",
"assets/assets/flags/gw_flag.png": "365668f6bbcd2298be4b63b042d38874",
"assets/assets/flags/ab_flag.png": "072a77038218b2e371e60cfead3d356c",
"assets/assets/flags/tn_flag.png": "0ef189043dd1d589858aa071edb6095e",
"assets/assets/flags/to_flag.png": "3a19d4d4d9998040fd8ae60ba085801f",
"assets/assets/flags/ba_flag.png": "0df7b21bbf134ee2d3d0748e4de98332",
"assets/assets/flags/mw_flag.png": "d464001bcd6c12170fc6f824e13f109d",
"assets/assets/flags/mv_flag.png": "16b8b1572614fa106981a6cac62a5733",
"assets/assets/flags/pg_flag.png": "e1bf4491edfa4f7e130fdb506a867ee0",
"assets/assets/flags/pf_flag.png": "5d3a05aac0adf9a85747c06d922254eb",
"assets/assets/flags/ye_flag.png": "57a189382c50264ac431aabecde1a332",
"assets/assets/flags/fi_flag.png": "067a43cf35f3fff35076c7d1d7953c7f",
"assets/assets/flags/jp_flag.png": "761c05bd8883182e4ab76c0879ffe4bc",
"assets/assets/flags/hm_flag.png": "40700dcc9ed367123c9afa09613be041",
"assets/assets/flags/ao_flag.png": "a22eb3393135c6dc50ef5d9f5660ae27",
"assets/assets/flags/cr_flag.png": "ba093853ec75b07f9226aa4a285c6cb4",
"assets/assets/flags/si_flag.png": "2e3d1938441b71bb1cdbe451383b30f7",
"assets/assets/flags/sh_flag.png": "aeb546b947b45c3ca7ad01e23c92bac7",
"assets/assets/flags/eg_flag.png": "353c4500731a855a8cf8bb7612a44f48",
"assets/assets/flags/pm_flag.png": "16685a6afd1bb747b7081340b1aee0b7",
"assets/assets/flags/pl_flag.png": "ffbd07ea54fda0ed989c8d93031ff25b",
"assets/assets/flags/bj_flag.png": "fbf054dcfa5b5b437c1dde8508b766c1",
"assets/assets/flags/it_flag.png": "682876b479c7fdc957cd85a1218f26de",
"assets/assets/flags/td_flag.png": "f401f28b8653491ae292fea8cee1eee9",
"assets/assets/flags/ki_flag.png": "6ec01654924e24a7a0b0e70361e6ede7",
"assets/assets/flags/kh_flag.png": "862c61da9745c87976083a08e51bb0fc",
"assets/assets/flags/za_flag.png": "2ceb507fce92ea1e2cf6254205180d84",
"assets/assets/flags/gq_flag.png": "736429d81723c6330811bdbc0843d2b6",
"assets/assets/flags/gp_flag.png": "e30d5159d28b9fdae7388a18add1c646",
"assets/assets/flags/nr_flag.png": "d3523b623cb7bd70b74aee0f5ecd0d22",
"assets/assets/flags/sc_flag.png": "137c7adf45e753f97a43b35c70213294",
"assets/assets/flags/sb_flag.png": "83b01144bf3c062968748d41a9d17251",
"assets/assets/flags/cx_flag.png": "9e183930a526487c4476928c0b7c2d72",
"assets/assets/flags/cy_flag.png": "73ad9a8f628c33aa06e1ddceda6b56d3",
"assets/assets/flags/ae_flag.png": "4cdfe46acc1c339a69b1772c18b446b1",
"assets/assets/flags/ad_flag.png": "e6d802e247e30e8cd7890bc2cc04af70",
"assets/assets/flags/gn_flag.png": "65be985f2608b06f7b01bb2f1d569dcd",
"assets/assets/flags/er_flag.png": "5cc7633c3d183cad6e4bcf1178a7bcff",
"assets/assets/flags/es_flag.png": "1b795bd8e9b73bfaa670dfc3e58e7b54",
"assets/assets/flags/nl_flag.png": "969c03af50e3a04a6d3c2311777216e9",
"assets/assets/flags/qa_flag.png": "9b1f066b97b68560f4cbde12ef1682fd",
"assets/assets/flags/az_flag.png": "aceade3c05565a134ea259ba6dde786b",
"assets/assets/flags/cf_flag.png": "265cdf740fae25a159caad3b066041e3",
"assets/assets/flags/cg_flag.png": "dc116a39845366302da31d7c5bcd6c90",
"assets/assets/flags/je_flag.png": "12df5de3acc1b568d1af3df47633b76d",
"assets/assets/flags/mc_flag.png": "31b754c80f684ddb4bf43bf6cb572aea",
"assets/assets/flags/ro_flag.png": "71236e73d8adbff66963b2d858b19c6c",
"assets/assets/flags/ps_flag.png": "8187c79eeded6e496593e0a65138ad9a",
"assets/assets/flags/pr_flag.png": "c55bf1a4c713f5d5d80a113d49e8741d",
"assets/assets/flags/bt_flag.png": "40bde18d006a8062a63a7a7d68c9a8b8",
"assets/assets/flags/tz_flag.png": "96a55d319e26d9ed965d9d4d18413deb",
"assets/assets/flags/kw_flag.png": "3dde7c3d4c8ed5815f56827e3df8c0bf",
"assets/assets/flags/vg_flag.png": "10af57e486e7d6fc4978fad744f58fa8",
"assets/assets/flags/hr_flag.png": "e74ef440dc279af36a1f3806733fbf19",
"assets/assets/flags/jo_flag.png": "b2647f5b5c9a4ed7ec377c2d3fb3017c",
"assets/assets/flags/cl_flag.png": "1f9eb25fb3435d4b10dc147175f385ec",
"assets/assets/flags/cm_flag.png": "096f0b7e614c6d24d841ecdcd8bafc6d",
"assets/assets/flags/aq_flag.png": "c3a604a73fbd1005ac2cb514c6b47a71",
"assets/assets/flags/ng_flag.png": "07ea06aafc9136131226f50b307fa26a",
"assets/assets/flags/nf_flag.png": "695967622e07133e3e0a11ae41ced5da",
"assets/assets/flags/sv_flag.png": "3300d7a9a5c5ffd9bd371d2082c35b66",
"assets/assets/flags/ge_flag.png": "31957fa79d2e36aba1d928e6d9b14b9f",
"assets/assets/flags/gd_flag.png": "6ad8e5854151f1023563650fd2de283d",
"assets/assets/flags/py_flag.png": "1ee444ab489ba26a8824f07c83e4bb4a",
"assets/assets/flags/re_flag.png": "21a8fcef26541cc6799d23925a0fbb61",
"assets/assets/flags/mh_flag.png": "72253dab7f12039946c3463629e80a7c",
"assets/assets/flags/dk_flag.png": "b5b47f5bcf2e8c5aaeb1c75f40d8a08d",
"assets/assets/flags/dj_flag.png": "9ee347d67f64ed955749349e92659be8",
"assets/assets/images/empty_cart.png": "a2fe410466420a0d56df298c3264f151",
"assets/assets/images/default_play.png": "e48d713dfae141c7563749b3ea442a73",
"assets/assets/images/Trash%2520Bin.png": "3231a9d9024e8b6aa720d9ae8ca8d8fd",
"assets/assets/images/curLoc.png": "d9067e0e1c8515d667dc87fe047992c9",
"assets/assets/images/onepay.png": "01f29c3fbebac8e8be99d8d64b8c4433",
"assets/assets/images/bell.png": "a757f41b20cac1dcbd686c78f4bd310c",
"assets/assets/images/no_image.png": "312ca80c5f72acd5f25f50c3c62e93c6",
"assets/assets/images/star_rating.png": "57e724756ad4cc167c5f0aa3179dda18",
"assets/assets/images/wallet_illu.png": "f34f5d61562eb29a9c41f8ebf750c61e",
"assets/assets/images/hide_icon.png": "3e062d010702db4cffc2d3149562b8f4",
"assets/assets/images/star_nav.png": "b1746cedbc7ec92a46d7312b8767bf36",
"assets/assets/images/star_nav_fill.png": "0e006f5789d813d8b63f4611188d4a3e",
"assets/assets/images/vegetable_home.png": "415ec5c060717003a97b827848922917",
"assets/assets/images/bread.png": "1e4677d7716d9aad6ea9a2438b109496",
"assets/assets/images/app_icon.png": "05c1e1d7581f8d432bc73f5b5559ab0e",
"assets/assets/images/cart_nav.png": "15d4c521c180f95a99086ea031af862b",
"assets/assets/images/success.gif": "fc998f41d034187dc7e6485e50a8e631",
"assets/assets/images/fruit_home.png": "6d726a11bae37053e39d40ca1166f17d",
"assets/assets/images/dairy.png": "edbfae7468ef4cc00660739552fe4a35",
"assets/assets/images/delivery.png": "05e9380630a5a649f81d2ebfb14f177a",
"assets/assets/images/user_nav.png": "d76f1288cda48f9a6514232e8989dad5",
"assets/assets/images/Arrow%2520Chevron%2520Right.png": "252560d4cb3c0c522b95ade150aa7893",
"assets/assets/images/Gold-Chain-PNG.png": "195ae1beca9a3e93369788e87953f3bf",
"assets/assets/images/cereal.png": "5defb7128051ad270feea8d57150469c",
"assets/assets/images/app_icon2.png": "ef08eafdd47dfe526e8e0c6a2a3248cb",
"assets/assets/images/Divider.png": "444214f4a380f9c2fbdad1cb4c9dcb57",
"assets/assets/images/map.png": "a8fbc3a5d288a4cf37d8c44e293e4819",
"assets/assets/images/logged-in.jpeg": "fd315373d136b5884f64901e538a22ae",
"assets/assets/images/log_out.png": "8e77c2dc439bb94171b3826616d9fc01",
"assets/assets/images/profile_user.png": "35d93e10071e4993a96d87a6ecd30e19",
"assets/assets/images/check_user.png": "05b5221dea23b1b801e1c1150d1a48ca",
"assets/assets/images/map_user.png": "03ad4441c034ab7e6d18975ff85daada",
"assets/assets/images/noti_user.png": "1a5aef37421c0058dee108c21ffaf964",
"assets/assets/images/home_nav_notfill.png": "810414ddf8df576bf1e1fd050010699f",
"assets/assets/images/vegetable.png": "d5373705aa1a55510e5e1b78036d128e",
"assets/assets/images/brand_logo.gif": "f13b289ca9149da2e17ed673294a22d3",
"assets/assets/images/Divider2.png": "ae3cf9935f0ac54724796aa530cbb88e",
"assets/assets/images/meat.png": "f9f5fb2a79fde681965412fb170272c5",
"assets/assets/images/default_profile.png": "ed28dc502c2bf1b0dea63d287f4b85e2",
"assets/assets/images/sample_profile.jpg": "e08b33fa81cc5f70892d77b9f75ce0ae",
"assets/assets/images/logo.png": "324c27dc33f01538856f266fd4857942",
"assets/assets/images/sort.png": "b07cacaf4f772477485c86bcba63a47e",
"assets/assets/images/seafood.png": "5d39a6dc3e5eb72531102239793ba906",
"assets/assets/images/money_transfer.jpeg": "2b6ed48c6173be9815e74f042187ef03",
"assets/assets/images/success.png": "f80df756b315fbb72670a78e82095c3c",
"assets/assets/images/cash_on_delivery.jpeg": "a470d2983d5b539076bb8c7175769254",
"assets/assets/images/herbs.png": "935b1a4f614fcd6fd3a847fcdb226e2d",
"assets/assets/images/fruit.png": "3ae258bcb79cd7992b21e92ff716dc95",
"assets/assets/images/edit.png": "3c0d66f44523f0d1650e9372d5547983",
"assets/assets/images/meat_home.png": "19b62bb6672815c1f2fd944d5bb41b05",
"assets/assets/images/egg_home.png": "337239c3126eaa2c0f9568687dde0605",
"assets/assets/images/map_pattern.png": "4722476cf466db5cda475873ce59de0c",
"assets/assets/images/profile_nav_fill.png": "eb840be079051e0b6c4d1af1b6d8d032",
"assets/assets/images/arrow_user.png": "252560d4cb3c0c522b95ade150aa7893",
"assets/assets/images/egg.png": "943ac3581a056588ea67ce9f47395531",
"assets/assets/images/home_nav.png": "b4ee2bc7479fe6df379b95deed256f65",
"assets/assets/images/cannedfood.png": "0988c7d1bfedbf6283d5b72d164c6e31",
"assets/assets/images/camera.png": "333a983c7bd1204b4c9799c7486ad26a",
"assets/assets/images/drinks.png": "2a279c07dace473644e6ff7c814ecfce",
"assets/assets/images/cart_nav_fill.png": "526adf03df050f742ab813082d3efc15",
"assets/assets/no_data_found.json": "401b1ca70691872d27db8bd66654fd47",
"assets/assets/tessdata_config.json": "d824b62ebb164c087e4857e1ac12bacc",
"assets/assets/icons/imgforgot.png": "89804f99a5c2c8076cb3adb8736e4e99",
"assets/assets/icons/icngmail.png": "c61dfa6d6843d08c2f89ee89f8fb2dcb",
"assets/assets/icons/down-arrow.png": "e243e8ad17b4e06b44389173ba79cb17",
"assets/assets/icons/icons8-plus-slash-minus-50.png": "9880eb60b5a4af2cb14778a4d4c958d1",
"assets/assets/icons/apple_logo.png": "42384bfd718c6d5278039a96ba8eb90b",
"assets/assets/icons/animated-gif-icon-11.jpg": "e256f76262b0d10b7d9e38e4fbc53a6c",
"assets/assets/icons/map_marker.png": "0cf13e58da38a8d8ae29ab8ece609103",
"assets/assets/icons/icons8-checkmark.png": "9103ebaaefea51d863a76a5bec899cdb",
"assets/assets/icons/icnfb.png": "b01213fbf5a15132b1b10ae494c59749",
"assets/assets/icons/price_tag.png": "0baba615b6a14f331b73261a59259601",
"assets/assets/icons/start.gif": "4f407d31b3cc3596139904c144ff088d",
"assets/assets/icons/gold/sell-gold-tang.png": "8cbeeff33f642052212ead0806ea47eb",
"assets/assets/icons/gold/gold-dealer.png": "85728af792c7c0fa6986532465268348",
"assets/assets/icons/gold/buy-gold-tang.png": "ad203a7ab6e66068504ae523f77076da",
"assets/assets/icons/gold/gold-sub-dealer.png": "4056647198ca387be179df7ff021468f",
"assets/assets/icons/gold/gold.png": "598fefd4dcd96907efb522e4c9f49d00",
"assets/assets/icons/icons8-sort-left-50.png": "f707edb674c978c370acb7be62ca43c0",
"assets/assets/icons/icons8-close_window.png": "c9e21b97da78ea6bc5c6807433ff8829",
"assets/assets/icons/up-arrow.png": "ee2351ddc5dad5ea6bd048e6682dfd3b",
"assets/assets/fonts/thai/THSarabunNew-Italic.ttf": "ad70682ea186a350b733876f781529a3",
"assets/assets/fonts/thai/THSarabunNew-BoldItalic.ttf": "54fe4a5916f7abddd9d08e183f811870",
"assets/assets/fonts/thai/NotoSansThai-Regular.ttf": "a84996ee5e940db8c7c2e1375728ca68",
"assets/assets/fonts/thai/THSarabunNew-Bold.ttf": "4a12003b4ffef670c25aa8065100befe",
"assets/assets/fonts/thai/THSarabunNew.ttf": "4c9a6e3d203c26982281fdda16ab5712",
"assets/assets/fonts/thai/NotoSansThai-Bold.ttf": "1296256d14a6c704f87967dc06583a64",
"assets/assets/fonts/PrintAble4U/PrintAble4U-Bold.otf": "596142e93e8d24f35f7d31419673b502",
"assets/assets/fonts/PrintAble4U/PrintAble4U-Bold.ttf": "dee8aac390ade77d71c524fbdb979230",
"assets/assets/fonts/PrintAble4U/PrintAble4U-Bold-Italic.otf": "03d6d64853baae63bdbd38135a1e96c6",
"assets/assets/fonts/PrintAble4U/PrintAble4U-Regular.ttf": "403b625bfc2468b90bb0d8ea1aef9c00",
"assets/assets/fonts/PrintAble4U/PrintAble4U-Italic.otf": "93d4eb7ee555bc749b861ac5c90e2048",
"assets/assets/fonts/PrintAble4U/PrintAble4U-Bold-Italic.ttf": "4b6b71468a154f3b0e8c68ee158979fe",
"assets/assets/fonts/PrintAble4U/PrintAble4U-Regular.otf": "c56bb513f73ca53802571ec1ac0034b5",
"assets/assets/fonts/PrintAble4U/PrintAble4U-Italic.ttf": "1a0aaabebecad3f1b2a95715d8b76189",
"assets/assets/fonts/PrintAble4U/Memo%2520PrintAble4U.txt": "9b5d80701474dfdc44b5d11e289df13b",
"assets/assets/fonts/NotoSansLao-Regular.ttf": "4751a7bb4b539409452d7f1bc131ebbd",
"canvaskit/skwasm.js": "1ef3ea3a0fec4569e5d531da25f34095",
"canvaskit/skwasm_heavy.js": "413f5b2b2d9345f37de148e2544f584f",
"canvaskit/skwasm.js.symbols": "0088242d10d7e7d6d2649d1fe1bda7c1",
"canvaskit/canvaskit.js.symbols": "58832fbed59e00d2190aa295c4d70360",
"canvaskit/skwasm_heavy.js.symbols": "3c01ec03b5de6d62c34e17014d1decd3",
"canvaskit/skwasm.wasm": "264db41426307cfc7fa44b95a7772109",
"canvaskit/chromium/canvaskit.js.symbols": "193deaca1a1424049326d4a91ad1d88d",
"canvaskit/chromium/canvaskit.js": "5e27aae346eee469027c80af0751d53d",
"canvaskit/chromium/canvaskit.wasm": "24c77e750a7fa6d474198905249ff506",
"canvaskit/canvaskit.js": "140ccb7d34d0a55065fbd422b843add6",
"canvaskit/canvaskit.wasm": "07b9f5853202304d3b0749d9306573cc",
"canvaskit/skwasm_heavy.wasm": "8034ad26ba2485dab2fd49bdd786837b"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
